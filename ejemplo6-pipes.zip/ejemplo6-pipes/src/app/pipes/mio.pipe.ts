import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'mio'
})
export class MioPipe implements PipeTransform {

  transform(dato: unknown, ...args: unknown[]): unknown {
    // Retornar el dato modificado segun los argumentos recibidos
    // return dato + " modificado " + args[0];

    // Retornar las n primeras palabras del texto, n es el argumento 0.
    let num_palabras = <number>args[0];
    return (<string>dato).split(" ", num_palabras);
  }

}
