import { Directive, ElementRef, HostBinding, HostListener, Renderer2, ViewChild } from '@angular/core';

@Directive({
  selector: '[appContarClicks]'
})
export class ContarClicksDirective {

  numeroClicks: number = 0;

  @HostBinding('style.font-size') // Funciona style.fontSize
  size: string = '';

  @HostBinding('style.opacity') 
  opacidad: number = 0.1;

  @ViewChild('dato')
  dato?: ElementRef;

  constructor(private renderer: Renderer2, private elRef: ElementRef) { }

  @HostListener('click')
  procesarClicks(): void{
    this.numeroClicks++;
    this.size = (15 + this.numeroClicks + "px");
    this.opacidad += 0.1;
    
    this.dato.nativeElement.innerHTML = this.numeroClicks;

    this.renderer.setProperty(this.dato?.nativeElement, "innerHTML", 
        `${this.numeroClicks}`);
  }

}
