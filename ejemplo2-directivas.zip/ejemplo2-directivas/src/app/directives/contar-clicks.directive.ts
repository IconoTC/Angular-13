import { Directive, ElementRef, HostBinding, HostListener, Renderer2, ViewChild } from '@angular/core';

@Directive({
  selector: '[appContarClicks]'
})
export class ContarClicksDirective {

  numeroClicks: number = 0;

  @HostBinding('style.font-size') // Funciona style.fontSize
  size: string = '';

  @HostBinding('style.opacity') 
  opacidad: number = 0.1;

  constructor(private renderer: Renderer2, private elRef: ElementRef) { }

  @HostListener('click')
  procesarClicks(): void{
    this.numeroClicks++;
    this.size = (15 + this.numeroClicks + "px");
    this.opacidad += 0.1;
    
    let contenidoAnterior = this.elRef.nativeElement.innerHTML;
    let nuevoContenido = contenidoAnterior + " " + this.numeroClicks;
    this.elRef.nativeElement.innerHTML = nuevoContenido;
  }

}
