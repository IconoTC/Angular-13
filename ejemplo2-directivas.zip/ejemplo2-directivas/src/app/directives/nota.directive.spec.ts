import { NotaDirective } from './nota.directive';

describe('NotaDirective', () => {
  it('should create an instance', () => {
    const directive = new NotaDirective();
    expect(directive).toBeTruthy();
  });
});
