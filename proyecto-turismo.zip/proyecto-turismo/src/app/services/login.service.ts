import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private angularFireAuth: AngularFireAuth) { }

  login(email: string, pw: string){
    return this.angularFireAuth.signInWithEmailAndPassword(email,pw);
  }

  registro(email: string, pw: string){
    return this.angularFireAuth.createUserWithEmailAndPassword(email,pw);
  }

  logout(){
    return this.angularFireAuth.signOut();
  }

  comprobarLogado(){
    return this.angularFireAuth.authState;
  }
}
