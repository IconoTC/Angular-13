export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyD4ebOqaPISd53C6vBSf7038swet06aLRM",
    authDomain: "angular-indra-14-marzo-anabel.firebaseapp.com",
    projectId: "angular-indra-14-marzo-anabel",
    storageBucket: "angular-indra-14-marzo-anabel.firebasestorage.app",
    messagingSenderId: "685586941619",
    appId: "1:685586941619:web:ead2521e5e9222a05252c6"
  }
};
